/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./documentsIframe/iframeControl.tsx":
/*!*******************************************!*\
  !*** ./documentsIframe/iframeControl.tsx ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"iframe\": () => (/* binding */ iframe)\n/* harmony export */ });\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @fluentui/react */ \"@fluentui/react\");\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst stackTokens = {\n  childrenGap: 5\n};\nconst stackStyles = {\n  root: {\n    width: \"100%\"\n  }\n};\nconst stackItemStyles = {\n  root: {\n    display: \"flex\",\n    width: \"100%\",\n    height: \"600px\"\n  }\n};\nconst iframe = (props) => {\n  const [options, setOptions] = react__WEBPACK_IMPORTED_MODULE_1__.useState([]);\n  const [selectedItem, setSelectedItem] = react__WEBPACK_IMPORTED_MODULE_1__.useState();\n  const [selectedUrl, setSelectedUrl] = react__WEBPACK_IMPORTED_MODULE_1__.useState();\n  let map;\n  const buildurl = (location, id, type, url) => {\n    if (type.toLocaleLowerCase() === \"sharepointdocumentlocation\") {\n      props.context.webAPI.retrieveRecord(type, id, \"\").then(\n        (success) => {\n          if (success._parentsiteorlocation_value !== success.sitecollectionid) {\n            buildurl(location, success._parentsiteorlocation_value, \"sharepointdocumentlocation\", success.relativeurl + \"/\" + url);\n          } else {\n            buildurl(location, success._parentsiteorlocation_value, \"sharepointsite\", success.relativeurl + \"/\" + url);\n          }\n        },\n        (error) => {\n          console.log(error);\n        }\n      );\n    } else {\n      props.context.webAPI.retrieveRecord(type, id, \"\").then(\n        (success) => {\n          var _a;\n          if (typeof map === \"undefined\") {\n            map = [{ key: location.id, url: success.absoluteurl + \"/\" + url }];\n          } else {\n            if (!map.includes({ key: location.id, url: success.absoluteurl + \"/\" + url }))\n              map.push({ key: location.id, url: success.absoluteurl + \"/\" + url });\n          }\n          let opts = options;\n          if (!opts.includes(props.dropdownOptions.find((x) => x.id === location.id).dropdownOption))\n            opts.push(props.dropdownOptions.find((x) => x.id === location.id).dropdownOption);\n          setOptions(opts);\n          setSelectedItem(options[0]);\n          setSelectedUrl((_a = map == null ? void 0 : map.find((x) => x.key === options[0].key)) == null ? void 0 : _a.url);\n        },\n        (error) => {\n          console.log(error);\n        }\n      );\n    }\n  };\n  const onChange = (event, option, index) => {\n    var _a;\n    setSelectedItem(option);\n    setSelectedUrl((_a = map == null ? void 0 : map.find((x) => x.key === (option == null ? void 0 : option.key))) == null ? void 0 : _a.url);\n  };\n  if (props.dropdownOptions.length > 0) {\n    props.dropdownOptions.forEach((opt) => {\n      buildurl(opt, opt.id, opt.type, \"\");\n    });\n  }\n  return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Stack, {\n    tokens: stackTokens,\n    styles: stackStyles\n  }, /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Stack.Item, {\n    align: \"baseline\"\n  }, /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Dropdown, {\n    label: \"Document Location\",\n    selectedKey: selectedItem ? selectedItem.key : options.length > 0 ? options[0].key : \"\",\n    onChange,\n    options\n  })), /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_1__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_0__.Stack.Item, {\n    align: \"auto\",\n    styles: stackItemStyles\n  }, /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_1__.createElement(\"iframe\", {\n    src: selectedUrl,\n    title: \"SharePoint Documents\",\n    width: \"100%\"\n  })));\n};\n\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./documentsIframe/iframeControl.tsx?");

/***/ }),

/***/ "./documentsIframe/index.ts":
/*!**********************************!*\
  !*** ./documentsIframe/index.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"documentsIframe\": () => (/* binding */ documentsIframe)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _iframeControl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./iframeControl */ \"./documentsIframe/iframeControl.tsx\");\n\n\nclass documentsIframe {\n  constructor() {\n  }\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  }\n  updateView(context) {\n    let locations = [];\n    for (let index in context.parameters.DocumentLocations.records) {\n      locations.push({\n        dropdownOption: {\n          key: context.parameters.DocumentLocations.records[index].getRecordId(),\n          text: context.parameters.DocumentLocations.records[index].getFormattedValue(\"name\")\n        },\n        id: context.parameters.DocumentLocations.records[index].getRecordId(),\n        type: context.parameters.DocumentLocations.getTargetEntityType()\n      });\n    }\n    const props = { dropdownOptions: locations, context };\n    return react__WEBPACK_IMPORTED_MODULE_0__.createElement(\n      _iframeControl__WEBPACK_IMPORTED_MODULE_1__.iframe,\n      props\n    );\n  }\n  getOutputs() {\n    return {};\n  }\n  destroy() {\n  }\n}\n\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./documentsIframe/index.ts?");

/***/ }),

/***/ "@fluentui/react":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = React;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./documentsIframe/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('ktcs.documentsIframe', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.documentsIframe);
} else {
	var ktcs = ktcs || {};
	ktcs.documentsIframe = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.documentsIframe;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}